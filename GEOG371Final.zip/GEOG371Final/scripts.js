var map = L.map('map').setView([44.06, -121.31], 8);

var Esri_OceanBasemap = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Ocean/World_Ocean_Base/MapServer/tile/{z}/{y}/{x}', {
	attribution: 'Tiles &copy; Esri &mdash; Sources: GEBCO, NOAA, CHS, OSU, UNH, CSUMB, National Geographic, DeLorme, NAVTEQ, and Esri',
	maxZoom: 20
}).addTo(map);

fetch('SSL_226_Critical_Habitat_AK.json')
    .then(response => response.json())
    .then(data => {
        L.geoJSON(data).addTo(map);
    })
    .catch(error => console.error('Error: ', error));

fetch('Snowy_Plover_Range_-_CWHR_B154_[ds929].geojson')
    .then(response => response.json())
    .then(data => {
        L.geoJSON(data).addTo(map);
    })
    .catch(error => console.error('Error: ', error));

    fetch('SeaTurtleLeatherback_20120126.json')
    .then(response => response.json())
    .then(data => {
        L.geoJSON(data, {
            style: {
                color: 'darkgreen', // Border color
                fillColor: 'darkgreen', // Fill color
                weight: 2, // Border width
                opacity: 1, // Border opacity
                fillOpacity: 0.5 // Fill opacity
            }
        }).addTo(map);
    })